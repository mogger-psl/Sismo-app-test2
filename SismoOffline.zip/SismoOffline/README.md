# Sismo Offline 🌎📱

Demo escolar de detección experimental de movimiento usando el acelerómetro de Android y comunicación Bluetooth entre dos teléfonos.

## Qué hace

- Los dos teléfonos usan la misma APK.
- El teléfono dentro de la caja funciona como **Sensor**.
- El otro funciona como **Monitor**.
- El sensor mide aceleración lineal y busca varios picos de movimiento cercanos.
- Cuando detecta un evento, manda `EARTHQUAKE|magnitud` por Bluetooth.
- El monitor cambia inmediatamente a una pantalla de alerta.
- No necesita Internet, GPS ni servidor externo.
- Incluye **Simular temblor** para hacer la demostración sin depender del algoritmo.

## Antes de abrir la app

1. Empareja los dos teléfonos desde Ajustes > Bluetooth.
2. Instala la misma APK en ambos.
3. Al abrirla, concede el permiso de **Dispositivos cercanos**.
4. En el teléfono que va en la caja, selecciona **Sensor** y pulsa **Iniciar detector**.
5. En el teléfono que mostrará el aviso, selecciona **Monitor**, actualiza la lista, selecciona el teléfono sensor y pulsa **Conectar con sensor**.
6. Pulsa **Simular temblor** para probar el enlace o sacude la caja de forma controlada.

## Importante para la exposición

Este proyecto detecta movimiento del teléfono. No predice terremotos ni calcula una magnitud sísmica real. Para un sistema real se necesitarían múltiples sensores, sincronización temporal, filtrado avanzado, localización y un algoritmo de detección sísmica validado.

La pantalla de alerta contiene texto de demostración y debe revisarse antes de usarla como aplicación de seguridad real.

## Estructura

- `MainActivity.kt`: entrada y permiso Bluetooth.
- `MainScreen.kt`: interfaz principal.
- `AlertScreen.kt`: interfaz de alerta.
- `Components.kt`: componentes reutilizables de Compose.
- `EarthquakeDetector.kt`: procesamiento del acelerómetro.
- `BluetoothManager.kt`: conexión RFCOMM y mensajes.
- `SismoApp.kt`: estado y coordinación de todo.
