package com.example.sismooffline.core

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.UUID

class BluetoothManager(
    private val adapter: BluetoothAdapter?
) {

    companion object {
        private const val SERVICE_NAME = "SismoOffline"
        private val SERVICE_UUID: UUID =
            UUID.fromString("4d0d0f71-2fa3-4c5c-8d7a-2f4a68df7b12")
    }

    private var serverSocket: BluetoothServerSocket? = null
    private var socket: BluetoothSocket? = null
    private var writer: BufferedWriter? = null
    private var listening = false

    @SuppressLint("MissingPermission")
    fun pairedDevices(): List<BluetoothDevice> {
        return adapter?.bondedDevices?.toList()?.sortedBy { it.name ?: it.address } ?: emptyList()
    }

    @SuppressLint("MissingPermission")
    fun startServer(
        onMessage: (String) -> Unit,
        onStatus: (String) -> Unit
    ) {
        if (adapter == null) {
            onStatus("Bluetooth no disponible")
            return
        }

        if (!adapter.isEnabled) {
            onStatus("Activa Bluetooth en ajustes")
            return
        }

        if (listening) return
        listening = true
        onStatus("Esperando al otro teléfono…")

        Thread {
            try {
                serverSocket = adapter.listenUsingRfcommWithServiceRecord(
                    SERVICE_NAME,
                    SERVICE_UUID
                )

                while (listening) {
                    val incoming = serverSocket?.accept() ?: break
                    attachSocket(incoming, onMessage, onStatus)
                }
            } catch (e: Exception) {
                if (listening) onStatus("Servidor Bluetooth: ${e.message ?: "error"}")
            }
        }.start()
    }

    @SuppressLint("MissingPermission")
    fun connect(
        device: BluetoothDevice,
        onMessage: (String) -> Unit,
        onStatus: (String) -> Unit
    ) {
        if (adapter == null) {
            onStatus("Bluetooth no disponible")
            return
        }
        if (!adapter.isEnabled) {
            onStatus("Activa Bluetooth en ajustes")
            return
        }

        Thread {
            try {
                socket?.close()
                val newSocket = device.createRfcommSocketToServiceRecord(SERVICE_UUID)
                socket = newSocket
                onStatus("Conectando con ${device.name ?: device.address}…")
                newSocket.connect()
                attachSocket(newSocket, onMessage, onStatus)
            } catch (e: Exception) {
                onStatus("No se pudo conectar: ${e.message ?: "error"}")
            }
        }.start()
    }

    @Synchronized
    fun send(message: String) {
        try {
            writer?.apply {
                write(message)
                newLine()
                flush()
            }
        } catch (_: Exception) {
            // The UI will show the disconnection through the reader thread.
        }
    }

    @SuppressLint("MissingPermission")
    private fun attachSocket(
        newSocket: BluetoothSocket,
        onMessage: (String) -> Unit,
        onStatus: (String) -> Unit
    ) {
        try {
            socket = newSocket
            writer = BufferedWriter(OutputStreamWriter(newSocket.outputStream))
            onStatus("Bluetooth conectado")

            Thread {
                try {
                    val reader = BufferedReader(InputStreamReader(newSocket.inputStream))
                    while (true) {
                        val line = reader.readLine() ?: break
                        onMessage(line)
                    }
                } catch (_: Exception) {
                    onStatus("Bluetooth desconectado")
                }
            }.start()
        } catch (e: Exception) {
            onStatus("Error de Bluetooth: ${e.message ?: "error"}")
        }
    }

    fun close() {
        listening = false
        try { serverSocket?.close() } catch (_: Exception) { }
        try { socket?.close() } catch (_: Exception) { }
        serverSocket = null
        socket = null
        writer = null
    }
}
