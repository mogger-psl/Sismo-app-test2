package com.example.sismooffline.core

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import kotlin.math.sqrt

/**
 * Demo detector based on the phone accelerometer.
 *
 * It removes most of the gravity component with a low-pass filter and looks
 * for repeated bursts of linear acceleration. This detects movement; it is
 * NOT a seismometer and cannot predict earthquakes.
 */
class EarthquakeDetector(
    private val sensorManager: SensorManager,
    private val onDetection: (magnitude: Float) -> Unit
) : SensorEventListener {

    private val accelerometer: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val gravity = FloatArray(3)
    private var threshold = 2.5f
    private var hitCount = 0
    private var windowStart = 0L
    private var cooldownUntil = 0L

    fun setSensitivity(sensitivity: Float) {
        // 1 = less sensitive, 10 = more sensitive.
        threshold = 4.5f - ((sensitivity - 1f) / 9f) * 3.3f
    }

    fun start(): Boolean {
        val sensor = accelerometer ?: return false
        hitCount = 0
        windowStart = 0L
        return sensorManager.registerListener(
            this,
            sensor,
            SensorManager.SENSOR_DELAY_GAME
        )
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return

        // Low-pass filter: estimate gravity.
        val alpha = 0.80f
        gravity[0] = alpha * gravity[0] + (1f - alpha) * event.values[0]
        gravity[1] = alpha * gravity[1] + (1f - alpha) * event.values[1]
        gravity[2] = alpha * gravity[2] + (1f - alpha) * event.values[2]

        // High-pass result: mostly movement, with gravity removed.
        val x = event.values[0] - gravity[0]
        val y = event.values[1] - gravity[1]
        val z = event.values[2] - gravity[2]
        val magnitude = sqrt(x * x + y * y + z * z)

        val now = SystemClock.elapsedRealtime()
        if (magnitude < threshold || now < cooldownUntil) return

        if (windowStart == 0L || now - windowStart > 800L) {
            windowStart = now
            hitCount = 0
        }

        hitCount++

        // Require several samples close together to reduce isolated false triggers.
        if (hitCount >= 3) {
            cooldownUntil = now + 8_000L
            hitCount = 0
            windowStart = now
            onDetection(magnitude)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
