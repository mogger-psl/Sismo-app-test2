package com.example.sismooffline.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AlertScreen(
    magnitude: Float,
    onDismiss: () -> Unit
) {
    BackHandler(onBack = onDismiss)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFF3E0))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp, Alignment.CenterVertically)
    ) {
        Text("⚠️", fontSize = 64.sp)
        Text(
            "MOVIMIENTO DETECTADO",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF9A0007),
            textAlign = TextAlign.Center
        )
        Text(
            "Magnitud de aceleración registrada: %.2f m/s²".format(magnitude),
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center
        )
        Text(
            "⚠️ varios celulares han registrado temblores cerca de tu zona.\n\n" +
                "Acciones recomendadas:\n" +
                "• preparar una mochila con suministros no perecederos.\n" +
                "• reunir familiares y personas cercanas a ti.\n" +
                "• evitar balcones, fachadas de edificios y cualquier estructura que pueda colapsar.\n" +
                "• si estás en el exterior, busca un lugar abierto, lejos de estructuras que puedan colapsar y causar accidentes.\n" +
                "• durante el movimiento, agáchate, cúbrete y sujétate bajo una estructura resistente si es posible.\n\n" +
                "MANTENGA LA CALMA",
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium,
            lineHeight = 26.sp
        )

        Button(onClick = onDismiss) {
            Text("Entendido")
        }

        Text(
            "DEMO ESCOLAR: este sistema detecta movimiento, no predice terremotos.",
            style = MaterialTheme.typography.labelSmall,
            textAlign = TextAlign.Center
        )
    }
}
