package com.example.sismooffline.ui

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.hardware.SensorManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.example.sismooffline.core.BluetoothManager
import com.example.sismooffline.core.EarthquakeDetector

@Composable
fun SismoApp() {
    val context = LocalContext.current

    val bluetoothAdapter = remember {
        BluetoothAdapter.getDefaultAdapter()
    }
    val bluetoothManager = remember {
        BluetoothManager(bluetoothAdapter)
    }
    val sensorManager = remember {
        context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    }
    val detector = remember {
        EarthquakeDetector(sensorManager) { magnitude ->
            bluetoothManager.send("EARTHQUAKE|$magnitude")
        }
    }

    var sensorMode by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("Listo") }
    var devices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
    var selectedDevice by remember { mutableStateOf<BluetoothDevice?>(null) }
    var sensitivity by remember { mutableStateOf(6f) }
    var monitoring by remember { mutableStateOf(false) }
    var alertMagnitude by remember { mutableStateOf<Float?>(null) }

    DisposableEffect(Unit) {
        detector.setSensitivity(sensitivity)
        onDispose {
            detector.stop()
            bluetoothManager.close()
        }
    }

    LaunchedEffect(sensorMode) {
        if (!sensorMode) {
            devices = try {
                bluetoothManager.pairedDevices()
            } catch (_: SecurityException) {
                emptyList()
            }
        }
    }

    if (alertMagnitude != null) {
        AlertScreen(
            magnitude = alertMagnitude ?: 0f,
            onDismiss = { alertMagnitude = null }
        )
        return
    }

    MainScreen(
        sensorMode = sensorMode,
        onSensorMode = {
            detector.stop()
            monitoring = false
            sensorMode = true
            status = "Modo sensor"
        },
        onMonitorMode = {
            detector.stop()
            monitoring = false
            sensorMode = false
            status = "Modo monitor"
            devices = try {
                bluetoothManager.pairedDevices()
            } catch (_: SecurityException) {
                emptyList()
            }
        },
        status = status,
        devices = devices,
        selectedDevice = selectedDevice,
        onSelectDevice = { selectedDevice = it },
        sensitivity = sensitivity,
        onSensitivityChange = {
            sensitivity = it
            detector.setSensitivity(it)
        },
        monitoring = monitoring,
        onStartSensor = {
            detector.setSensitivity(sensitivity)
            bluetoothManager.startServer(
                onMessage = { line ->
                    if (line.startsWith("EARTHQUAKE|")) {
                        val parts = line.split("|")
                        val magnitude = parts.getOrNull(1)?.toFloatOrNull() ?: 0f
                        alertMagnitude = magnitude
                    }
                },
                onStatus = { message -> status = message }
            )

            val started = detector.start()
            if (started) {
                monitoring = true
                status = "🟢 Detector activo; esperando movimiento"
            } else {
                detector.stop()
                bluetoothManager.close()
                status = "Este teléfono no tiene acelerómetro compatible."
            }
        },
        onConnectMonitor = {
            selectedDevice?.let { device ->
                monitoring = true
                status = "Conectando…"
                bluetoothManager.connect(
                    device = device,
                    onMessage = { line ->
                    if (line.startsWith("EARTHQUAKE|")) {
                        val parts = line.split("|")
                        val magnitude = parts.getOrNull(1)?.toFloatOrNull() ?: 0f
                        alertMagnitude = magnitude
                    }
                },
                    onStatus = { message -> status = message }
                )
            }
        },
        onSimulate = {
            bluetoothManager.send("EARTHQUAKE|3.50")
            status = "Evento de prueba enviado"
        },
        onRefreshDevices = {
            devices = try {
                bluetoothManager.pairedDevices()
            } catch (_: SecurityException) {
                emptyList()
            }
        }
    )
}
